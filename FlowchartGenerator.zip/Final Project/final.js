const canvas = document.getElementById("canvas");
const context = canvas.getContext("2d");

let currentShape = "";
let drawingStack = [];
let redoStack = [];

let mouseX = 0;
let mouseY = 0;

const circleBtn = document.getElementById("circleBtn");
circleBtn.addEventListener("click", () => {
  setShape("circle");
});

const rectangleBtn = document.getElementById("rectangleBtn");
rectangleBtn.addEventListener("click", () => {
  setShape("rectangle");
});

const diamondBtn = document.getElementById("diamondBtn");
diamondBtn.addEventListener("click", () => {
  setShape("diamond");
});

const triangleBtn = document.getElementById("triangleBtn");
triangleBtn.addEventListener("click", () => {
  setShape("triangle");
});

const verticalArrowBtn = document.getElementById("verticalArrowBtn");
verticalArrowBtn.addEventListener("click", () => {
  setShape("verticalarrow");
});

const horizontalArrowBtn = document.getElementById("horizontalArrowBtn");
horizontalArrowBtn.addEventListener("click", () => {
  setShape("horizontalarrow");
});

const clearBtn = document.getElementById("clear");
clearBtn.addEventListener("click", () => {
  clearCanvas();
});

const saveBtn = document.getElementById("save");
saveBtn.addEventListener("click", () => {
  saveCanvas();
});

const undoBtn = document.getElementById("undo");
undoBtn.addEventListener("click", () => {
  undo();
});

const redoBtn = document.getElementById("redo");
redoBtn.addEventListener("click", () => {
  redo();
});

function setShape(shape) {
  currentShape = shape;
}

function clearCanvas() {
  context.clearRect(0, 0, canvas.width, canvas.height);
  drawingStack = [];
  redoStack = [];
}

function saveCanvas() {
  const link = document.createElement("a");
  link.href = canvas.toDataURL();
  link.download = "canvas.jpg";
  link.click();
}

function undo() {
  if (drawingStack.length > 0) {
    const lastState = drawingStack.pop();
    redoStack.push(context.getImageData(0, 0, canvas.width, canvas.height));
    context.putImageData(lastState, 0, 0);
  }
}

function redo() {
  if (redoStack.length > 0) {
    const nextState = redoStack.pop();
    drawingStack.push(context.getImageData(0, 0, canvas.width, canvas.height));
    context.putImageData(nextState, 0, 0);
  }
}

canvas.addEventListener("mousedown", draw);

function draw(e) {
  const rect = canvas.getBoundingClientRect();
  mouseX = e.clientX - rect.left;
  mouseY = e.clientY - rect.top;

  switch (currentShape) {
    case "circle":
      drawCircle();
      break;
    case "rectangle":
      drawRectangle();
      break;
    case "diamond":
      drawDiamond();
      break;
    case "triangle":
      drawTriangle();
      break;
    case "verticalarrow":
      drawVerticalArrow();
      break;
    case "horizontalarrow":
      drawHorizontalArrow();
      break;
    default:
      break;
  }

  saveDrawingState();
}

function saveDrawingState() {
  const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
  drawingStack.push(imageData);
  redoStack = [];
}
function drawCircle() {
  const radius = 40;
  let x = 0;
  let y = radius;
  let d = 3 - 2 * radius;

  while (x <= y) {
    drawCirclePoints(x, y);
    x++;

    if (d < 0) {
      d = d + 4 * x + 6;
    } else {
      y--;
      d = d + 4 * (x - y) + 10;
    }

    drawCirclePoints(x, y);
  }
}

function drawCirclePoints(x, y) {
  context.fillRect(mouseX + x, mouseY + y, 1, 1);
  context.fillRect(mouseX - x, mouseY + y, 1, 1);
  context.fillRect(mouseX + x, mouseY - y, 1, 1);
  context.fillRect(mouseX - x, mouseY - y, 1, 1);

  context.fillRect(mouseX + y, mouseY + x, 1, 1);
  context.fillRect(mouseX - y, mouseY + x, 1, 1);
  context.fillRect(mouseX + y, mouseY - x, 1, 1);
  context.fillRect(mouseX - y, mouseY - x, 1, 1);
}

function drawRectangle() {
  const width = 80;
  const height = 40;

  drawBresenhamLine(
    mouseX - width / 2,
    mouseY - height / 2,
    mouseX + width / 2,
    mouseY - height / 2
  );
  drawBresenhamLine(
    mouseX + width / 2,
    mouseY - height / 2,
    mouseX + width / 2,
    mouseY + height / 2
  );
  drawBresenhamLine(
    mouseX + width / 2,
    mouseY + height / 2,
    mouseX - width / 2,
    mouseY + height / 2
  );
  drawBresenhamLine(
    mouseX - width / 2,
    mouseY + height / 2,
    mouseX - width / 2,
    mouseY - height / 2
  );
}

function drawBresenhamLine(x1, y1, x2, y2) {
  const dx = Math.abs(x2 - x1);
  const dy = Math.abs(y2 - y1);
  const sx = x1 < x2 ? 1 : -1;
  const sy = y1 < y2 ? 1 : -1;
  let err = dx - dy;

  while (true) {
    context.fillRect(x1, y1, 1, 1);

    if (x1 === x2 && y1 === y2) {
      break;
    }

    const e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      x1 += sx;
    }
    if (e2 < dx) {
      err += dx;
      y1 += sy;
    }
  }
}

function drawDiamond() {
  const size = 70;
  const halfSize = size / 2;

  const topX = mouseX;
  const topY = mouseY - halfSize;
  const rightX = mouseX + halfSize;
  const rightY = mouseY;
  const bottomX = mouseX;
  const bottomY = mouseY + halfSize;
  const leftX = mouseX - halfSize;
  const leftY = mouseY;

  drawBresenhamLine(topX, topY, rightX, rightY);
  drawBresenhamLine(rightX, rightY, bottomX, bottomY);
  drawBresenhamLine(bottomX, bottomY, leftX, leftY);
  drawBresenhamLine(leftX, leftY, topX, topY);
}

function drawBresenhamLine(x1, y1, x2, y2) {
  const dx = Math.abs(x2 - x1);
  const dy = Math.abs(y2 - y1);
  const sx = x1 < x2 ? 1 : -1;
  const sy = y1 < y2 ? 1 : -1;
  let err = dx - dy;

  while (true) {
    context.fillRect(x1, y1, 1, 1);

    if (x1 === x2 && y1 === y2) {
      break;
    }

    const e2 = 2 * err;
    if (e2 > -dy) {
      err -= dy;
      x1 += sx;
    }
    if (e2 < dx) {
      err += dx;
      y1 += sy;
    }
  }
}

function drawTriangle() {
  const size = 50;

  const topX = mouseX;
  const topY = mouseY - size;
  const rightX = mouseX + size / 2;
  const rightY = mouseY;
  const leftX = mouseX - size / 2;
  const leftY = mouseY;

  drawBresenhamLine(topX, topY, rightX, rightY);
  drawBresenhamLine(rightX, rightY, leftX, leftY);
  drawBresenhamLine(leftX, leftY, topX, topY);
}

function drawVerticalArrow() {
  const size = 40;

  context.beginPath();
  context.moveTo(mouseX, mouseY - size / 2);
  context.lineTo(mouseX, mouseY + size / 2);
  context.stroke();
}

function drawHorizontalArrow() {
  const size = 40;

  context.beginPath();
  context.moveTo(mouseX - size / 2, mouseY);
  context.lineTo(mouseX + size / 2, mouseY);
  context.stroke();
}
